To run game: play.bat not main.exe
if it doesn't work, install vcredist_x86.exe and then try play.bat again.
if is doesn't work even with vcredist_x86.exe installed, 
send me bugreport with console output, email initd5@gmail.com
