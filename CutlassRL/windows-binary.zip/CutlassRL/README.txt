To run game: main.exe
if it doesn't work, install vcredist_x86.exe and then try main.exe again.
if is doesn't work even with vcredist_x86.exe installed, 
send me bugreport, email initd5@gmail.com
